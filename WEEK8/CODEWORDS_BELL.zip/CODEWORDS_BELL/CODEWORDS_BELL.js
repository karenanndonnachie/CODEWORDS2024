var song;
function preload(){
  song= loadSound("data/bell.mp3");
}

function setup() {
 createCanvas(windowWidth, windowHeight);
 background(255, 255, 0);
 getAudioContext().suspend();
}

function draw() {

}
function mousePressed() {
  if (getAudioContext().state !== 'running') {
    getAudioContext().resume();
    song.play();
    song.loop();
   }
}
